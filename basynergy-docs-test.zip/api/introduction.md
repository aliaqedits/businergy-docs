# API Introduction

این بخش مرجع API باسینرژی است.

## Base URL

```text
https://api.example.com/v1
```

> مقدار بالا صرفاً نمونه است و باید با آدرس واقعی API جایگزین شود.

## Authentication

برای دسترسی به API معمولاً از Token استفاده می‌شود.
